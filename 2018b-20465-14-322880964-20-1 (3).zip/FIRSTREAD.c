
#include "project.h"

int DC=0;/*Data Counter*/
static int IC=START_ADDRESS;/*Instructions COunter*/
static int data[DATA_MAX_SIZE];/*Data*/
static bool SF=false;/*Symbol Flag*/

int size_of_table;
void putbinary(int num){/*this method converts a number to binary and puts it into the data file*/
	int mask=1<<(WORD_SIZE);/*We use a mask, and every time we use the mask & and to get the current char*/
	FILE *fd;
	fd=fopen("data.txt","a+");
	fseek(fd,0,SEEK_END);
	while(mask)/*moving the mask each loop to get all of the characters*/
	{
		if((num&mask)==0)
		{
			fputc('0',fd);
		}
		else
		{
			fputc('1',fd);			
		}
		mask>>=1;
	}
	fputc('\n',fd);
	fclose(fd);	
}
void writedata(int* data){/*This method puts all the data(from the data array into the data.txt file*/
int c=0;
	while(c<DC){
	putbinary(data[c]);
	c+=1;
	}
}
int check(char *command)/*This method checks if a command is legal and returns 0 */
{
                if(strcmp(command,"mov")==0)
		{
                        return 0;
		}
                if(strcmp(command,"cmp")==0)
		{
                        return 0;
		}
                if(strcmp(command,"add")==0)
		{
                        return 0;
		}
                if(strcmp(command,"sub")==0)
		{
                        return 0;
		}
                if(strcmp(command,"not")==0)
		{
                        return 0;
		}
                if(strcmp(command,"clr")==0)
		{
                        return 0;
		}
                if(strcmp(command,"lea")==0)
		{
                        return 0;
		}
                if(strcmp(command,"inc")==0)
		{
                        return 0;
		}
                if(strcmp(command,"dec")==0)
		{
                        return 0;
		}			
                if(strcmp(command,"jmp")==0)
		{
                        return 0;
		}
                if(strcmp(command,"bne")==0)
		{
                        return 0;
		}
                if(strcmp(command,"red")==0)
		{
                        return 0;
		}
                if(strcmp(command,"prn")==0)
		{
                        return 0;
		}
                if(strcmp(command,"jsr")==0)
		{
                        return 0;
		}
                if(strcmp(command,"rts")==0)
		{
                        return 0;
		}
                if(strcmp(command,"stop")==0)
		{
                        return 0;
		}
                if(strcmp(command,".data")==0)
		{
                        return 0;
		}
                if(strcmp(command,".string")==0)
		{
                        return 0;
		}
                if(strcmp(command,".entry")==0)
		{
                        return 0;
		}
                if(strcmp(command,".extern")==0)
		{
                        return 0;
		}
        
return 1;
}
int opcode(char *command)/*This method returns the opcode of a command*/
{
                if(strcmp(command,"mov")==0)
		{
                        return 0;
		}	
                if(strcmp(command,"cmp")==0)
		{
                        return 1;
		}
                if(strcmp(command,"add")==0)
		{
                        return 2;
		}
                if(strcmp(command,"sub")==0)
		{
                        return 3;
		}
                if(strcmp(command,"not")==0)
		{
                        return 4;
		}
                if(strcmp(command,"clr")==0)
		{
                        return 5;
		}
                if(strcmp(command,"lea")==0)
		{
                        return 6;
		}
                if(strcmp(command,"inc")==0)
		{
                        return 7;
		}
                if(strcmp(command,"dec")==0)
		{
                        return 8;
		}			
                if(strcmp(command,"jmp")==0)
		{
                        return 9;
		}
                if(strcmp(command,"bne")==0)
		{
                        return 10;
		}
                if(strcmp(command,"red")==0)
		{
                        return 11;
		}
                if(strcmp(command,"prn")==0)
		{
                        return 12;
		}
                if(strcmp(command,"jsr")==0)
		{
                        return 13;
		}
                if(strcmp(command,"rts")==0)
		{
                        return 14;
		}
                if(strcmp(command,"stop")==0)
		{
                        return 15;
		}
                if(strcmp(command,".data")==0)
		{
                        return -1;
		}
                if(strcmp(command,".string")==0)
		{
                        return -1;
		}
                if(strcmp(command,".entry")==0)
		{
                        return 16;
		}
                if(strcmp(command,".extern")==0)
		{
                        return -1;
		}
        
return -1;
}


int commandSize(char *v1,char *v2)/*This method returns the size of a command according to it's arguments*/
{
int a1,a2,size=0;
a1=addressing_method(v1);
a2=addressing_method(v2);
if(a1==0 || a1==1 || a1==2){/*The size of the command is determined by the adressing methods of it's arguments*/
size=3;
}
else if(a2==3){
size=2;
}
else{
size=3;
}
return size;
}


symbol getsymbol(char line[PARAM_SIZE]){/*This method gets a symbol from a line in the file*/
/*The command will return the symbol from the line, in case that the line is a regular line it will return empty symbol named NULL and in case of error it will return empty symbol named Non*/
char label[PARAM_SIZE]="",type[LINE_SIZE]="",var1[PARAM_SIZE]="",var2[PARAM_SIZE]="",command[LINE_SIZE]="";
bool STF=false,NF=false,A2F=false,NEG=false;/*String flag and number flag*/
int x=0,y=0,NC=0;
symbol *s=(symbol *)malloc(sizeof(s));/*The symbol that will be returned*/
s->name[0]='\0';
while(line[x]== ' ' || line[x]== '	'){
x+=1;
}
        while(line[x]!=':'){/*Running until the end of the label(inserting the label to the variable label)*/
        if(line[x]==' ' || line[x]=='	'){/*if the character is a whitespace then its a regular command or extern*/
		if(check(label)==1){/*Checking if the command is legal*/
		        printf("Error:ilegal command: %s\n",label);
        		strcpy(s->name,"Non");                          
       			return *s;       
		}
                if(strcmp(label,".extern")==0){/*checking if its extern, if it is we return an extern symbol*/
                SF=true;
                s->isExtern=true;
                s->address=0;
                s->isAction=false;
                        while(line[x]== ' ' || line[x]== '	'){/*Skiping whitespaces*/
                        x+=1;
                        }
                        while(line[x]!=',' && line[x]!=' '&& line[x]!='\n'&& line[x]!='	'){/*Getting the extern name*/
                        var1[y]=line[x];
                        x+=1;
			y+=1;
                        }               
                strcpy(s->name,var1);
                SF=false;
                return *s;       
                }
		else if(strcmp(label,".entry")==0){/*Checking if its an entry*/
                strcpy(s->name,"NULL");
                s->isExtern=true;
                s->address=0;
                s->isAction=false;
                return *s;   
		}
                else{/*if its a command we find its size and increase IC and return NULL symbol*/
                        while(line[x]== ' ' || line[x]== '	'){
                        x+=1;
                        }
                        if(line[x]=='\n'){/*If its a non parameter command*/
                        IC+=1;
                        }
                        else{
                        y=0;
                                while(line[x]!='\n'){
				if(line[x]=='('){/*checking if there is a '(' which means we use label adressining method*/
				y=0;
				A2F=true;/*Turning adressing methid 2 flag on if it is adressing method 2*/
				x+=1;
					while(line[x]== ' '|| line[x]== '	'){
                                	x+=1;
                               		}
/*if its adressing method 2, we get the parametrs names and check the size that the command will take using commandsize*/
					while(line[x]!=' ' && line[x]!=',' && line[x]!='	'){
					var1[y]=line[x];
					y+=1;
					x+=1;
					}
					x+=1;
					while(line[x]== ' '|| line[x]== '	'){
                                	x+=1; 						}
					var1[y]='\0';
					y=0;
					while(line[x]!=' ' && line[x]!='\n' && line[x]!='	' && line[x]!= ')'){
					var2[y]=line[x];
					y+=1;
					x+=1;
					}
					var2[y]='\0';
					IC+=commandSize(var1,var2);
					IC+=1;
			                strcpy(s->name,"NULL");
               				s->isExtern=true;
                			s->address=0;
                			s->isAction=false;
                			return *s;  
				}
				if(!A2F && (line[x]==' ' || line[x]=='	' || line[x]==','))
				break;
                                var1[y]=line[x];
                                y+=1;
                                x+=1;
                                }
                        var1[y]='\0';/*if its not adressing method 2, we again use command size nad check how much params there is to update IC*/
                                while(line[x]== ' '|| line[x]== '	'){
                                x+=1;
                                }
                                if(line[x]=='\n'){
					IC+=2;          
                                }
                                else{
                                x+=1;
                                y=0;
                                        while(line[x]!=' ' && line[x]!='\n' && line[x]!='	'){
                                        var2[y]=line[x];
                                        x+=1;
                                        y+=1;
                                        }
                                var2[y]='\0';
                                IC+=commandSize(var1,var2);
                                }               
                        }
                strcpy(s->name,"NULL");/*returning NULL struct since this is a command which is not in the symbol table*/
                s->isExtern=true;
                s->address=0;
                s->isAction=false;
                return *s;               
                }
        }       
        label[x]=line[x];
        x+=1;
        }
label[x]='\0';
SF=true;/*symbol is being declared since its not a command*/ 
if(x==0){/*checking if there is a label or its just ":"*/
printf("Error:the label must have name\n");
strcpy(s->name,"Non");                          
return *s;       
}
x+=1;
while(line[x]== ' ' || line[x]=='	'){/*going through all of the whitespaces*/
        x+=1;
}
if(line[x]=='.'){/*if the command after the label starts with . its either .string or .data*/
        x+=1;
        while(line[x]!=' '){/*finding if its string or data*/
                type[y]=line[x];        
                x+=1;
                y+=1;
        }
        type[y]='\0';
        if(strcmp(type,"data")==0){/*if its data then we create the correct symbol and add the numbers to the data and increase DC(We also check that the numbers are legal and return errors if they arent)*/
                strcpy(s->name,label);
                s->address=DC;
                s->isExtern=false;
                s->isAction=false;
                while(x<LINE_SIZE){
                        NC=0;
			NF=false;
			NEG=false;
			if(line[x]=='\n')
			break;
                        while(line[x]!=','){
                                if(line[x]<'0' || line[x]>'9'){
                                        if(line[x]=='-' && !NF){
                                        NEG=true;
                                        NF=true;
                                        }
                                        else if(line[x]=='+' && !NF){
                                        NF=true;
                                        }
					
                                        else if(!NF && line[x]!=' '){   
                                        printf("Error:ilegal number\n");
                                        SF=false;       
                            		strcpy(s->name ,"Non");
                                        return *s;       
                                        }
                                        else if(line[x]==' ' || line[x]=='	' ){
                                        }
					else if(line[x]==',')
					{
					 NF=false;
					}
                                        else if(line[x]=='\n'){
                                        break;                                  
                                        }
                                        else{
                                        printf("Error:ilegal number\n");
                                        SF=false;
                                        strcpy(s->name,"Non");
                                        return *s;       
                                        }
                                }
                                else{
                                NF=true;
                                data[DC]=data[DC]*10+(line[x]-'0');
                                NC+=1;                          
                                }
                        x+=1;
                        }
			if(NEG){
			data[DC]=data[DC]*(-1);			
			}
                        DC+=1;
                        if(line[x]=='\n'){
                        break;}
                        x+=1;
                }
        }
        if(strcmp(type,"string")==0){/*if its string then we create the correct symbol and add the string to the data and increase DC(We also check that the string is legal and return errors if it isnt)*/
                strcpy(s->name,label);
                s->address=DC;
                s->isExtern=false;
                s->isAction=false;
                while(x<LINE_SIZE){
                        if(STF){
                                if(line[x]=='"'){
				data[DC]=0;
				DC+=1;
                                STF=false;
                                break;
                                }       
                                else{
                                data[DC]=line[x];
                                DC+=1;
                                }
                        }
                        else{
                                if(line[x]=='"'){
                                STF=true;
                                }
                                else if(line[x]==' ' || line[x]=='	'){}
                                else{
                                printf("Error:ilegal string\n");
                                SF=false;
                                strcpy(s->name,"Non");                          
                                return *s;       
                                }                               
                        }
                x+=1;           
                }
        
        }
}
else{/*in this case the label is a command label*/
y=0;
        while(line[x]!=' ' && line[x]!='\n' && line[x]!='	'){
        command[y]=line[x];
        x+=1;
        y+=1;
        }
        command[y]='\0';
        if(opcode(command)==-1){/*checking if the command is legal using its opcode*/
        printf("Error:ilegal command: %s\n",command);/*returning error symbol if its ilegal*/
        SF=false;
        strcpy(s->name,"Non");                          
        return *s;       
        }
        else{/* if it is legal we create action symbol and retrun it, we also add the size it will take up to IC(in the same way we did in the begining of this method)*/
                strcpy(s->name,label);
                s->isExtern=false;
                s->isAction=true;
                s->address=IC;
                while(line[x]== ' ' || line[x]== '	'){
                x+=1;
                }
                if(line[x]=='\n'){
                IC+=1;
                }
                else{
                y=0;
                        while( line[x]!='\n'){
				if(line[x]=='('){
				y=0;
				A2F=true;
				x+=1;
					while(line[x]== ' '|| line[x]== '	'){
                                	x+=1;
                               		}
					while(line[x]!=' ' && line[x]!=',' && line[x]!='	'){
					var1[y]=line[x];
					y+=1;
					x+=1;
					}
					x+=1;
					while(line[x]== ' '|| line[x]== '	'){
                                	x+=1; 						}
					var1[y]='\0';
					y=0;
					while(line[x]!=' ' && line[x]!='\n' && line[x]!='	' && line[x]!= ')'){
					var2[y]=line[x];
					y+=1;
					x+=1;
					}
					var2[y]='\0';
					IC+=commandSize(var1,var2);
					IC+=1;  
				}				
				if(!A2F && (line[x]==' ' || line[x]=='	' || line[x]==','))
				break;
                        var1[y]=line[x];
                        y+=1;
                        x+=1;
                        }
                var1[y]='\0';
                        while(line[x]== ' '|| line[x]== '	'){
                        x+=1;
                        }
                        if(line[x]=='\n' && !A2F){
				IC+=2;  
                        }
                        else if(!A2F){
                        x+=1;
                        y=0;
                                while(line[x] && line[x]!=' '){
                                var2[y]=line[x];
                                x+=1;
                                y+=1;
                                }
                        var2[y]='\0';
                        IC+=commandSize(var1,var2);
                        }               
                }
        }
}
SF=false;
return *s;/*returning the symbol*/
}


symbol * FirstRead(char *file){/*This function is the function that will commit the first read of the file*/
bool error=false;
int x=0,y=0;
char line[LINE_SIZE];
symbol *table=(symbol *)malloc(sizeof(symbol)*10);
FILE *fp=fopen(file, "rw");/*opening the file */
        if(fp==NULL){
                printf("Error: cannot open the file\n");
                return NULL;
        }
        while(fgets(line,LINE_SIZE,fp)){/*reading the file line by line*/
                if(line[0]!='\n' && line[0]!=';'){
                table[x]=getsymbol(line);/*using the method getsymbol to create the table*/
                        if(strcmp(table[x].name,"NULL")==0){/*if its not a symbol*/
                        x-=1;           
                        }
                 	else{
				if(strcmp(table[x].name,"Non")==0){/*if there is an error*/
				error=true;
				x-=1;
	               		}
			}
                x+=1;
                }

        }
	if(error){ exit(0);}
        y=0;
        while(y<x){/*going through the table again and adding IC to the data symbols*/
                if(!table[y].isExtern && !table[y].isAction){
                table[y].address+=IC;
                }
                y+=1;
        }
writedata(data);/*writing the data file*/
size_of_table=x;/*setting the finale size of the table*/
Secondread(file,table);/*calling secondread*/
return table;
}
