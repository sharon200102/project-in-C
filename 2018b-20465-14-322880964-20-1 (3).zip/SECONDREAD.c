#include "project.h"


extern int DC;
extern int size_of_table;
FILE *ext;

int INC=100;
char* stradd(const char* a, const char* b){
    size_t len = strlen(a) + strlen(b);
    char *ret = (char*)malloc(len * sizeof(char) + 1);
    *ret = '\0';
    return strcat(strcat(ret, a) ,b);
}
void check_ext(char operand[PARAM_SIZE],symbol sym[],int IC)
{
	int i=0;
	for(i=0;i<size_of_table;i++)
	{
	 if(sym[i].isExtern==true && strcmp(sym[i].name,operand)==0)
	 {
		fputs(sym[i].name,ext);
		fputc('	',ext);
		fprintf(ext,"%d",(100+IC));
		fputc('\n',ext);
	 }
	}
}



void convert(char *name){
int line=100;
char *file=stradd(name,".ob");
FILE *f1=fopen("text1.txt", "rw");
FILE *f2=fopen(file, "a+");
char c=fgetc(f1);
fprintf(f2,"%d %d\n0%d ",(INC-100),DC,line);
line+=1;
	while(c!=EOF){
		if(c=='1'){
		fputc('/',f2);
		}else if(c=='0'){
		fputc('.',f2);
		}else if (c=='\n'){
		fputc(c,f2);
		fprintf(f2,"0%d ",line);
		line+=1;
		}
		c=fgetc(f1);
	}

remove("text1.txt");
f1=fopen("data.txt", "rw");
c=fgetc(f1);
	while(c!=EOF){
		if(c=='1'){
		fputc('/',f2);
		}
		else if(c=='0'){
		fputc('.',f2);
		}
		else if (c=='\n'){
		fputc(c,f2);
			if(line<(INC+DC)){
			fprintf(f2,"0%d ",line);
			line+=1;
			}
		}
		c=fgetc(f1);
	}

remove("data.txt");
}
/* The method returns the number of the addressing method for the operand inserted*/
int addressing_method(char name_of_operand[])
{
	int i;
	if(name_of_operand[0]=='#')
	return 0;
	for(i=0;i<strlen(name_of_operand);i++)
	{
		if(name_of_operand[i]=='(')
		return 2;
	}
	if((name_of_operand[0]=='r')&&(name_of_operand[1]>47)&&(name_of_operand[1]<56)&&(strlen(name_of_operand)==2))/* there are 8 registers the first is r0 therefore the last is r7 */
	return 3;
	return 1;
	
}
/* The method writes the integer inserted as a string*/
void write(unsigned int *p,int IC)
{
	unsigned int mask=	1<<(WORD_SIZE);
	int i=0;
	FILE *fd;
	char line_two_print[WORD_SIZE+2];
	fd=fopen("text1.txt","a+");
	fseek(fd,0,SEEK_END);
	while(mask)
	{
		if(((*p)&mask)==0)
		{
			line_two_print[i]='0';
		}
		else
		{
			line_two_print[i]='1';			
		}
		mask>>=1;
		i++;
	}
	fputs(line_two_print,fd);
	fputc('\n',fd);
	fclose(fd);
	INC+=1;
		
}
/* The method is beening used if the command is a one parameter command. or if there is no connection between the parameters*/
/* The method builds the addtional words to the basic word (the info on the parameters)*/
void addtional_word1(char name[],int an,symbol sym[],int IC)
{

	int i=0,ARE,num;
	unsigned int *p;
	sword s1;
	reg r1;
	number n1;
	if( an==1)
	{

		for(i=0;i<size_of_table;i++)
		{
			if(strcmp(name,sym[i].name)==0)
			{
				if(sym[i].isExtern==true)
					ARE=1;
				else
					ARE=2;
				s1.ARE=ARE;
				s1.address=sym[i].address;	
			}	
		}
		p=(unsigned int*)(&s1);
	
	write(p,IC);
	}
	if(an==3)
	{
		while(name[i]!='r')
		{
			i++;
		}
		if(IC==1)
		{
		r1.ARE=0;
		r1.des_r=0;
		r1.source_r=name[i+1]-ASCII_OF_ZERO;/* 48 is the ascii code of zero*/
		p=(unsigned int*)(&r1);
		write(p,IC);
		}
		if(IC==2)
		{
		r1.ARE=0;
		r1.des_r=name[i+1]-ASCII_OF_ZERO;/* 48 is the ascii code of zero*/
		r1.source_r=0;
		p=(unsigned int*)(&r1);
		write(p,IC);
		}
	}
	if(an==0)
	{
		while(name[i]!='#')
		{
			i++;
		}
	num=atoi(name+i+1);
	n1.ARE=0;
	n1.num=num;
	p=(unsigned int*)(&n1);
	write(p,IC);		
	}
}
/* The method builds a basic word with all the parameters inserted*/
void basic_word(int ARE,int des_addr,int source_addr,int opcode,int first_param,int second_param,int IC)
{
	unsigned int *p;
	bword b1;
	b1.ARE=ARE;
	b1.des_addr=des_addr;
	b1.source_addr=source_addr;
	b1.opcode=opcode;
	b1.first_param=first_param;
	b1.second_param=second_param;
	p=(unsigned int *)(&b1);
	write(p,IC);
	
}
/* The method is used if the command is a two parameters command, if both of the parameters are registers, it will build only one addtional word, otherwise it will build two.*/
int addtional_word2(char first_operand[],char second_operand[],int first_am,int second_am, symbol sym[],int IC)
{
	unsigned int *p;
	int i=0,j=0;
	reg r1;
	if((first_am==3)&&(second_am==3))
	{
		while(first_operand[i]!='r')
		{
			i++;
		}
		while(first_operand[i]!='r')
		{
			j++;
		}
		r1.ARE=0;
		r1.des_r=second_operand[i+1]-ASCII_OF_ZERO;/* 48 is the ascii code of zero*/
		r1.source_r=first_operand[i+1]-ASCII_OF_ZERO;/* 48 is the ascii code of zero*/
		p=(unsigned int*)(&r1);
		write(p,IC);
		return IC+1;
	}
	else
	{
		addtional_word1(first_operand,first_am,sym,1);
		addtional_word1(second_operand,second_am,sym,2);
		return IC+2;
	}
}

/* The method is beening used when the addresing method of the parameter is two */
int addressing_number_two(char first_operand[],int opcode,int IC,symbol sym[])
{
	int i=0,j=0;
	char symbol_name[MAX_SIZE_OF_SYMBOL];
	char first_param[PARAM_SIZE];
	char second_param[PARAM_SIZE];
	while(first_operand[i]!='(')
	{
		if(first_operand[i]>ASCII_OF_SPACE)
		{
			symbol_name[j]=first_operand[i];
			j++;
		}
		i++;
	}
	symbol_name[j]='\0';
	i++;
	check_ext(symbol_name,sym,IC+1);
	j=0;
	while(first_operand[i]!=',')
	{
		if(first_operand[i]>ASCII_OF_SPACE)
		{
			first_param[j]=first_operand[i];
			j++;
		}
		i++;
	}
	first_param[j]='\0';
	check_ext(first_param,sym,IC+2);
	i++;
	j=0;
	while(first_operand[i]!=')')
	{
		if(first_operand[i]>ASCII_OF_SPACE)
		{
			second_param[j]=first_operand[i];
			j++;
		}
		i++;	
	}
	second_param[j]='\0';
	if(addressing_method(second_param)==3 && addressing_method(first_param)==3)
	check_ext(second_param,sym,IC+2);
	else
	check_ext(second_param,sym,IC+3);
	basic_word(0,2,0,opcode,addressing_method(second_param),addressing_method(first_param),IC);
 	addtional_word1(symbol_name,1,sym,IC+1);/* its already known that symbol_name is a symbol*/
	IC=addtional_word2(first_param,second_param,addressing_method(first_param),addressing_method(second_param),sym,IC+2);
	return IC;
	
	
	
}
/* The method finds the parameters of rest, and begins the process of building the words*/
int two_param_command(char rest[],int opcode,int IC,symbol sym[])
{
	int i,fcounter=0,scounter=0,first_am, second_am;/*am is short for addressing_method*/
	char first_operand[PARAM_SIZE];/* 31 is the longest operand name  possible*/
	char second_operand[PARAM_SIZE];/* 31 is the longest operand name possible*/
	bool isfirst=true;
	bool issecond=false;
	for(i=0;i<strlen(rest);i++)
	{
		if(rest[i]>32)/* bigger then the ascii code of space and tab*/
		{
			if(rest[i]==',')
			{
				first_operand[fcounter]='\0';
				isfirst=false;
				issecond=true;
			}
			
			if(isfirst==true)
			{
			 	first_operand[fcounter]=rest[i];
				fcounter++;
			}
			if((issecond==true)&&(rest[i]!=','))
			{
			 	second_operand[scounter]=rest[i];
				scounter++;
			}

			
					
		}
			
	}
	second_operand[scounter]='\0';
	check_ext(first_operand,sym,IC+1);
	if(addressing_method(second_operand)==3 && addressing_method(first_operand)==3)
	check_ext(second_operand,sym,IC+1);
	else
	check_ext(second_operand,sym,IC+2);
	first_am=addressing_method(first_operand);
	second_am=addressing_method(second_operand);
	basic_word(0,second_am,first_am,opcode,0,0,IC);
	IC=addtional_word2(first_operand,second_operand,first_am,second_am,sym,IC+1);
	return IC;
	
	
}
/* The method finds the parameter of rest, and begins the process of building the words*/
int one_param_command(char rest[],int opcode,int IC,symbol sym[])
{
	int i,fcounter=0,first_am;
	char first_operand[PARAM_SIZE];/* 31 is the longest operand name  possible*/
	for(i=0;i<strlen(rest);i++)
	{
		if(rest[i]>ASCII_OF_SPACE)/* bigger then the ascii code of space and tab*/
		{
			first_operand[fcounter]=rest[i];
			fcounter++;
		}
	}
	first_operand[fcounter]='\0';
	check_ext(first_operand,sym,IC+1);
	first_am=addressing_method(first_operand);
	if(first_am==2)/* second addressing method*/
	{
		return addressing_number_two(first_operand,opcode,IC,sym);
	}
	else
	{
		basic_word(0,first_am,0,opcode,0,0,IC);
		addtional_word1(first_operand,first_am,sym,2);
		return IC+2;
	}

}

int no_param_command(int opcode,int IC)
{
	basic_word(0,0,0,opcode,0,0,IC);
	return IC+1;
}

int issymbol(char line[],symbol sym[])
{
	char name_of_symbol[MAX_SIZE_OF_SYMBOL];
	int i,j=0,k;
	for(i=0;i<strlen(line);i++)
	{
		if(line[i]>ASCII_OF_SPACE)/* bigger then the ascii code of space and tab*/
		{ 
		
			if(line[i]==':')
			{
				name_of_symbol[j]='\0';
				for(k=0;k<size_of_table;k++)
				{
					if((strcmp(name_of_symbol,sym[k].name)==0)&&(sym[k].isAction==true))
					return i+1;/*to jump over the symbol in the line including the ':'*/
				}
				return -1;
			}
			else
			{
				name_of_symbol[j]=line[i];
				j++;
			}
		}
	}	
	return 0;
}
void entry_method(char rest[],symbol sym[])
{

	FILE *fd;
	char name [MAX_SIZE_OF_SYMBOL]; /* the biggest symbol is 31 chars long*/
	char address[MAX_SIZE_OF_ADDRES];/* address has max 10 digits*/
	int i=0,j=0;
	fd=fopen("entry.txt","a+");
	fseek(fd,0,SEEK_END);
	for(i=0;i<strlen(rest);i++)
	{
		if(rest[i]>ASCII_OF_SPACE)/* bigger then the ascii code of space and tab*/
		{
			name[j]=rest[i];
			j++;
		}
	}
	name[j]='\0';
		for(i=0;i<size_of_table;i++)
		{
			if(strcmp(name,sym[i].name)==0)
			{
				sprintf(address,"%d",sym[i].address);
				fputs(name,fd);
				fputc('	',fd);
				fputs(address,fd); 			
				fputc('\n',fd);
			}
		}
	fclose(fd);
}
/* The method uses the opcode to find out how many parameters does rset has, and calls the suitable methodes */
int num_of_param(char rest[],int opcode,int IC,symbol sym[])
{
	switch(opcode)
	{
		case 0:
		case 1:
		case 2:
		case 3:
		case 6:
		IC=two_param_command(rest,opcode,IC,sym);
		break;
		case 14:
		case 15:
		IC=no_param_command(opcode,IC);
		break;
		case 4:
		case 5:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
		IC=one_param_command(rest,opcode,IC,sym);
		break;
		case 16:
		entry_method(rest,sym);
		break;
		default:
		break;
		

		
	}
return IC;
}
void Secondread(char name_of_file[],symbol sym[])
{
	int IC=0,i=0,j=0,isr;/* isr is a short to issymbol return*/
	FILE *fd;
	char ch;
	char line[LINE_SIZE]/* 100 is the longest line possible*/;
	char name_of_command[MAX_NAME_OF_COMMAND];/* 10 is the max len of name of command line possible*/
	char rest[MAX_SIZE_OF_REST];
	if(!(fd=fopen(name_of_file,"r+")))
	{
		printf("cannot open file");
		exit(0);
	}
	
	while(!feof(fd))
	{
		strcpy(line," ");
		strcpy(name_of_command," ");
		strcpy(rest," ");
		i=0;
		j=0;
		ch=fgetc(fd);
		while((ch!='\n')&&(!feof(fd)))
		{
			line[i]=ch;
			ch=fgetc(fd);
			i++;
			
			
		}
		line[i]='\0';
		isr=issymbol(line,sym);
		if(isr!=-1) /* checks if not a guideline */
		{
			i=0;
			while((opcode(name_of_command)==-1)&&(i+isr<strlen(line)))
			 {
			   if(line[i+isr]>ASCII_OF_SPACE) /* bigger then the ascii code of space and tab*/
			   {
				
				name_of_command[j]=line[i+isr];
				name_of_command[j+1]='\0';
				j++;
			   }	
			   i++;
			 }
		 strcpy(rest,line+i+isr);
		 IC=num_of_param(rest,opcode(name_of_command),IC,sym);
		}
		
	

	
	}
	

		
	
	
	
		

} 
int main(int argc, char* argv[])
{       
	int i;
        char name_of_file[MAX_FILE_SIZE];/* 34 is the max length of file including .as*/ 
	char name_of_file_convert[MAX_FILE_SIZE];
	char name_of_file_ext[MAX_FILE_SIZE];

	if(argc==1)
	{
		printf(" You didn't insert any files");
		exit(0);
	}
	for(i=1;i<argc;i++)
	{
	strcpy(name_of_file,argv[i]);
	strcpy(name_of_file_convert,argv[i]);
	strcpy(name_of_file_ext,argv[i]);
	name_of_file[strlen(argv[i])]='.'; /* adding .as to the name of file*/
	name_of_file[strlen(argv[i])+1]='a';
	name_of_file[strlen(argv[i])+2]='s';
	name_of_file[strlen(argv[i])+3]='\0';
	ext=fopen(stradd(name_of_file_ext,".ext"), "a+");
	FirstRead(name_of_file);
	convert(name_of_file_convert);
	rename("entry.txt",stradd(name_of_file_convert,".ent"));
	
	

	}
	return 0;
}
