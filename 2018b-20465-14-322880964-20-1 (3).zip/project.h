#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>

#define LINE_SIZE 100/*We assumed that the max line size is 100*/
#define WORD_SIZE 13
#define PARAM_SIZE 31
#define START_ADDRESS 100
#define DATA_MAX_SIZE 100
#define MAX_FILE_SIZE 34
#define ASCII_OF_SPACE 32
#define MAX_NAME_OF_COMMAND 10
#define MAX_SIZE_OF_REST 90
#define MAX_SIZE_OF_SYMBOL 31
#define MAX_SIZE_OF_ADDRES 10
#define ASCII_OF_ZERO 48

typedef struct {
char name[31];	/* 31 is the longest name possible*/
int address;
bool isExtern;
bool isAction;
} symbol;
/*second read structs*/
typedef struct{
	unsigned int ARE:2;
	unsigned int num:12;
} number;
typedef struct{
	unsigned int ARE:2;
	unsigned int des_r:6;
	unsigned int source_r:6;
} reg;
typedef struct{
	unsigned int ARE:2;
	unsigned int address:12;
} sword;	/*sword is a short to symbol word*/
typedef struct{
	unsigned int ARE:2;
	unsigned int des_addr:2;
	unsigned int source_addr:2;
	unsigned int opcode:4;
	unsigned int first_param:2;
	unsigned int second_param:2;
	
} bword; /* bword is a short to basic word*/

/*first read methods*/
int opcode(char *command);
int commandSize(char *v1,char *v2);
symbol getsymbol(char line[100]);
symbol * FirstRead(char *file);
void putbinary(int num);
void writedata(int* data);
int check(char *command);

/*second read methods*/
int addressing_method(char name_of_operand[]);
void write(unsigned int *p,int IC);
void addtional_word1(char name[],int an,symbol sym[],int IC);
void basic_word(int ARE,int des_addr,int source_addr,int opcode,int first_param,int second_param,int IC);
int addtional_word2(char first_operand[],char second_operand[],int first_am,int second_am, symbol sym[],int IC);
int addressing_number_two(char first_operand[],int opcode,int IC,symbol sym[]);
int two_param_command(char rest[],int opcode,int IC,symbol sym[]);
int one_param_command(char rest[],int opcode,int IC,symbol sym[]);
int no_param_command(int opcode,int IC);
int issymbol(char line[],symbol sym[]);
void entry_method(char rest[],symbol sym[]);
int num_of_param(char rest[],int opcode,int IC,symbol sym[]);
void Secondread(char name_of_file[],symbol sym[]);
void convert(char *name);
char* stradd(const char* a, const char* b);
void open_ext_file( char * name,symbol sym[]);
void check_ext(char operand[31],symbol sym[],int IC);














